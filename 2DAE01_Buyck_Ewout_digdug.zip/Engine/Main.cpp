// COPY THE CODE BELOW IN THE MAIN FILE OF THE GAME PROJECT

#include "pch.h"

#include <vld.h>
#include "Engine.h"

#pragma warning( push )
#pragma warning(disable : 4100)
int main(int argc, char* argv[]) {
#pragma warning( pop )

	//meow::Engine engine{};
	//engine.Run();
	return 0;
}