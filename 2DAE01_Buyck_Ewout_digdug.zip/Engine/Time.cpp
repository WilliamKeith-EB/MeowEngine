#include "pch.h"
#include "Time.h"

float  meow::Time::GetDeltaT() const {

	return m_DeltaT;
}

float  meow::Time::GetFPS() const {

	return m_FPS;
}
