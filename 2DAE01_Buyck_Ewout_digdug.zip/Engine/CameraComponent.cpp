#include "pch.h"
#include "CameraComponent.h"


meow::CameraComponent::CameraComponent(const glm::vec4& backgroundColor) 
	: m_BackgroundColor{ backgroundColor } {
}
