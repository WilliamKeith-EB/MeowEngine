#pragma once

namespace meow {

	class CollisionListener {

	public:
		virtual void OnCollision() {}
	};
}